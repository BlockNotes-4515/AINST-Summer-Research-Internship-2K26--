
AMITY UNIVERSITY NOIDA - SYNTHETIC RADIATION DATASET

Columns:
latitude, longitude, temperature, humidity, pressure, wind_speed,
gamma_radiation, beta_radiation, alpha_radiation,
radiation_level, source_type, risk_zone
